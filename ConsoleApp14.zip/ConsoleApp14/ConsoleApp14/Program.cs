﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Globalization;

struct Dust
{
    public double Temperature, Humidity, Density, DustCapacity, ParticleSize, Resistivity;
    public string Conductivity, DustDispersiveness, Formation;
}

class Program
{
    // Считывание CSV-файла
    static List<Dust> ReadCsvFile(string fileName)
    {
        var dustList = new List<Dust>();

        try
        {
            if (!File.Exists(fileName))
            {
                Console.WriteLine($"Файл {fileName} не найден.");
                return dustList;
            }

            var lines = File.ReadAllLines(fileName);

            if (lines.Length <= 1)
            {
                Console.WriteLine("CSV файл пуст или содержит только заголовок.");
                return dustList;
            }

            foreach (var line in lines.Skip(1))
            {
                var parts = line.Split(';');

                // Проверка на корректное количество данных в строке
                if (parts.Length != 9 || parts.Any(p => string.IsNullOrWhiteSpace(p)))
                {
                    Console.WriteLine($"Недостаточно данных в строке: {line}");
                    continue;
                }

                try
                {
                    var dust = new Dust
                    {
                        Temperature = double.Parse(parts[0], new CultureInfo("ru-RU")),
                        Humidity = double.Parse(parts[1], new CultureInfo("ru-RU")),
                        Density = double.Parse(parts[2], new CultureInfo("ru-RU")),
                        DustCapacity = double.Parse(parts[3], new CultureInfo("ru-RU")),
                        ParticleSize = double.Parse(parts[4], new CultureInfo("ru-RU")),
                        Resistivity = double.Parse(parts[5], new CultureInfo("ru-RU")),
                        Conductivity = parts[6],
                        DustDispersiveness = parts[7],
                        Formation = parts[8]
                    };

                    dustList.Add(dust);
                }
                catch (FormatException ex)
                {
                    Console.WriteLine($"Ошибка формата данных в строке: {line} | Ошибка: {ex.Message}");
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка чтения CSV файла: {ex.Message}");
        }

        return dustList;
    }

    // Запись данных в CSV-файл
    static void WriteCsvFile(string fileName, List<Dust> dustArray)
    {
        try
        {
            using (var writer = new StreamWriter(fileName))
            {
                // Заголовок CSV-файла
                writer.WriteLine("Temperature;Humidity;Density;DustCapacity;ParticleSize;Resistivity;Conductivity;DustDispersiveness;Formation");

                foreach (var d in dustArray)
                {
                    writer.WriteLine($"{d.Temperature.ToString("F2", new CultureInfo("ru-RU"))};" +
                                     $"{d.Humidity.ToString("F2", new CultureInfo("ru-RU"))};" +
                                     $"{d.Density.ToString("F2", new CultureInfo("ru-RU"))};" +
                                     $"{d.DustCapacity.ToString("F2", new CultureInfo("ru-RU"))};" +
                                     $"{d.ParticleSize.ToString("F2", new CultureInfo("ru-RU"))};" +
                                     $"{d.Resistivity.ToString("F2", new CultureInfo("ru-RU"))};" +
                                     $"{d.Conductivity};{d.DustDispersiveness};{d.Formation}");
                }
            }
            Console.WriteLine($"Данные успешно сохранены в файл {fileName}.");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка при записи файла: {ex.Message}");
        }
    }

    // Основные статистические показатели
    static void GetStatistics(List<Dust> dustArray)
    {
        Console.WriteLine("\nОсновные статистические характеристики:\n");
        var numericStats = new Dictionary<string, List<double>>
        {
            { "Temperature", dustArray.Select(d => d.Temperature).ToList() },
            { "Humidity", dustArray.Select(d => d.Humidity).ToList() },
            { "Density", dustArray.Select(d => d.Density).ToList() },
            { "Dust Capacity", dustArray.Select(d => d.DustCapacity).ToList() },
            { "Particle Size", dustArray.Select(d => d.ParticleSize).ToList() },
            { "Resistivity", dustArray.Select(d => d.Resistivity).ToList() }
        };

        foreach (var stat in numericStats)
        {
            var data = stat.Value;
            Console.WriteLine($"{stat.Key}:");
            Console.WriteLine($"  Минимум: {data.Min():F2}");
            Console.WriteLine($"  Максимум: {data.Max():F2}");
            Console.WriteLine($"  Среднее: {data.Average():F2}");
            Console.WriteLine($"  Дисперсия: {data.Variance():F2}");
            Console.WriteLine($"  Стандартное отклонение: {data.StandardDeviation():F2}\n");
        }

        var textStats = new Dictionary<string, IEnumerable<IGrouping<string, Dust>>>
        {
            { "Conductivity", dustArray.GroupBy(d => d.Conductivity) },
            { "Dust Dispersiveness", dustArray.GroupBy(d => d.DustDispersiveness) },
            { "Formation", dustArray.GroupBy(d => d.Formation) }
        };

        foreach (var stat in textStats)
        {
            Console.WriteLine($"{stat.Key}:");
            foreach (var group in stat.Value)
            {
                Console.WriteLine($"  {group.Key}: {group.Count()} раз");
            }
            Console.WriteLine();
        }
    }

    static void Main(string[] args)
    {
        string inputFile = "C:\\Users\\user\\source\\repos\\ConsoleApp14\\ConsoleApp14\\dust.csv";
        string outputFile = "C:\\Users\\user\\source\\repos\\ConsoleApp14\\ConsoleApp14\\generated_dust.csv";

        // Считывание данных
        var dustArray = ReadCsvFile(inputFile);
        Console.WriteLine($"Загружено {dustArray.Count} записей.");

        if (dustArray.Count == 0)
        {
            Console.WriteLine("Нет данных для обработки.");
            return;
        }

        GetStatistics(dustArray);
        WriteCsvFile(outputFile, dustArray);
        Console.WriteLine("Работа завершена!");
    }
}

// Методы расширения для статистических расчетов
public static class StatisticsExtensions
{
    public static double Variance(this IEnumerable<double> values)
    {
        var avg = values.Average();
        return values.Average(v => Math.Pow(v - avg, 2));
    }

    public static double StandardDeviation(this IEnumerable<double> values)
    {
        return Math.Sqrt(values.Variance());
    }
}
